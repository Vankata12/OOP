package commands;

import database.Database;
import database.FileHandler;

/**
 * Команда за записване на базата данни в нов файл.
 */
public class SaveAsCommand implements Command {
    private Database db;

    /**
     * Създава нова инстанция на SaveAsCommand.
     * @param db Обект на базата данни, върху който ще се изпълни командата.
     */
    public SaveAsCommand(Database db) {
        this.db = db;
    }

    /**
     * Изпълнява командата за записване в нов файл.
     * Синтаксис: saveas <нов_файл>
     * @param args Масив от аргументи за командата. Очаква се един аргумент - името на новия файл.
     */
    @Override
    public void execute(String[] args) {
        if (args.length != 1) {
            System.out.println("Използване: saveas <нов_файл>");
            return;
        }
        try {
            db.setCatalogFile(args[0]);
            FileHandler.saveDatabase(db);
            System.out.println("Базата данни е записана успешно като " + args[0]);
        } catch (Exception e) {
            System.out.println("Грешка при запис: " + e.getMessage());
        }
    }
} 