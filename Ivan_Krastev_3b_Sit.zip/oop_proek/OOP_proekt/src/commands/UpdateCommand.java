package commands;

import database.Database;
import database.Table;
import datatypes.DataType;

import java.util.List;

/**
 * Команда за актуализиране на стойности в редове на таблица по дадено условие.
 */
public class UpdateCommand implements Command {
    private Database db;

    /**
     * Създава нова инстанция на UpdateCommand.
     * @param db Обект на базата данни, върху който ще се изпълни командата.
     */
    public UpdateCommand(Database db) {
        this.db = db;
    }

    /**
     * Изпълнява командата за актуализиране на редове.
     * Синтаксис: update <table> <col#> <value> <target_col#> <нова_стойност>
     * @param args Масив от аргументи за командата.
     */
    @Override
    public void execute(String[] args) {
        if (args.length != 5) {
            System.out.println("Използване: update <table> <col#> <value> <target_col#> <нова_стойност>");
            return;
        }

        String tableName = args[0];
        int colIndex;
        String valueString = args[2];
        int targetColIndex;
        String newValueString = args[4];

        Table table = db.getTable(tableName);
        if (table == null) {
            System.out.println("Грешка: Таблица \"" + tableName + "\" не съществува.");
            return;
        }

        try {
            colIndex = Integer.parseInt(args[1]);
            targetColIndex = Integer.parseInt(args[3]);

            if (colIndex < 0 || colIndex >= table.getColumnTypes().size() ||
                targetColIndex < 0 || targetColIndex >= table.getColumnTypes().size()) {
                System.out.println("Грешка: Невалидни индекси на колони.");
                return;
            }
        } catch (NumberFormatException e) {
            System.out.println("Грешка: Индексите на колони трябва да са числа.");
            return;
        }

        // Извличане на типовете данни
        DataType compareColType = table.getColumnTypes().get(colIndex);
        DataType targetColType = table.getColumnTypes().get(targetColIndex);

        // Парсване на стойностите за сравнение и актуализация
        Object parsedCompareValue = compareColType.parse(valueString);
        Object parsedNewValue;

        // Валидация и парсване на новата стойност
         if (newValueString.equalsIgnoreCase("NULL")) {
            parsedNewValue = null;
        } else {
            if (!targetColType.isValid(newValueString)) {
                System.out.println("Грешка: Невалидна нова стойност \"" + newValueString + "\" за колона \"" + table.getColumnNames().get(targetColIndex) + "\" (тип " + targetColType.getClass().getSimpleName() + ").");
                return;
            }
            parsedNewValue = targetColType.parse(newValueString);
        }

        int updatedCount = 0;
        for (List<Object> row : table.getRows()) {
            Object currentValue = row.get(colIndex);

            // Сравнение на текущата стойност с парснатата стойност за сравнение (с обработка на NULL)
            if ((currentValue == null && parsedCompareValue == null) || (currentValue != null && parsedCompareValue != null && currentValue.equals(parsedCompareValue))) {
                // Ако стойностите съвпадат (или и двете са NULL), актуализираме стойността в целевата колона
                row.set(targetColIndex, parsedNewValue);
                updatedCount++;
            }
        }

        System.out.println("Актуализирани " + updatedCount + " редове в таблица \"" + tableName + "\".");
    }
}
