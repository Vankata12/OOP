package commands;

import database.Database;
import database.Table;

/**
 * Команда за показване на структурата на таблица.
 * Извежда имената и типовете на колоните.
 */
public class DescribeCommand implements Command {
    private Database db;

    /**
     * Създава нова инстанция на DescribeCommand.
     * @param db Обект на базата данни, върху който ще се изпълни командата.
     */
    public DescribeCommand(Database db) {
        this.db = db;
    }

    /**
     * Изпълнява командата за описване на таблица.
     * Синтаксис: describe <table>
     * @param args Масив от аргументи за командата.
     */
    @Override
    public void execute(String[] args) {
        if (args.length != 1) {
            System.out.println("Използване: describe <table>");
            return;
        }
        String tableName = args[0];
        Table table = db.getTable(tableName);
        if (table == null) {
            System.out.println("Грешка: Таблица \"" + tableName + "\" не съществува.");
            return;
        }
        System.out.println("Колони на таблица \"" + tableName + "\":");
        for (int i = 0; i < table.getColumnNames().size(); i++) {
            System.out.println("- " + table.getColumnNames().get(i) + " (" + table.getColumnTypes().get(i).getClass().getSimpleName() + ")");
        }
    }
}
