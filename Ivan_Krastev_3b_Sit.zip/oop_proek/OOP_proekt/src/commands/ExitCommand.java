 package commands;

/**
 * Команда за изход от програмата.
 */
public class ExitCommand implements Command {

    /**
     * Изпълнява командата за изход.
     * Завършва изпълнението на програмата с код 0.
     * @param args Масив от аргументи за командата (не се използват в този случай).
     */
    @Override
    public void execute(String[] args) {
        System.out.println("Изход от програмата.");
        System.exit(0);
    }
}
