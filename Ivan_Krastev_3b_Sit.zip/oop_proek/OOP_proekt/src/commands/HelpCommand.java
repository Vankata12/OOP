package commands;
/**
 * Команда за показване на помощна информация за наличните команди.
 */
public class HelpCommand implements Command {

    /**
     * Изпълнява командата за помощ.
     * Извежда списък и кратко описание на всички поддържани команди.
     * @param args Масив от аргументи за командата (не се използват в този случай).
     */
    @Override
    public void execute(String[] args) {
        System.out.println("Поддържани команди:");
        System.out.println("  import <файл>           - Импортира таблица от файл.");
        System.out.println("  showtables            - Показва имената на всички заредени таблици.");
        System.out.println("  describe <table>        - Показва структурата на таблица.");
        System.out.println("  print <table>           - Отпечатва съдържанието на таблица.");
        System.out.println("  insert <table> <стойности...> - Вмъква нов ред в таблица.");
        System.out.println("  delete <table> <col#> <стойност> - Изтрива редове от таблица по условие.");
        System.out.println("  update <table> <col#> <стойност> <target_col#> <нова_стойност> - Актуализира редове в таблица.");
        System.out.println("  count <table> <col#> <стойност> - Преброява редове по условие.");
        System.out.println("  aggregate <table> <col#> <функция> - Извършва агрегатна функция върху колона (sum, avg, min, max).");
        System.out.println("  innerjoin <table>1 <table>2 <col1#> <col2#> - Извършва INNER JOIN между две таблици.");
        System.out.println("  rename <table> <ново_име> - Преименува таблица.");
        System.out.println("  addcolumn <table> <име_на_колона> <тип> - Добавя нова колона към таблица (int, float, string).");
        System.out.println("  close                 - Затваря текущата база данни.");
        System.out.println("  save                  - Записва текущата база данни.");
        System.out.println("  saveas <файл>           - Записва текущата база данни в нов файл.");
        System.out.println("  exit                  - Излиза от програмата.");
    }
}
