package commands;

import database.Database;
import database.Table;
import datatypes.DataType;

import java.util.List;

/**
 * Команда за отпечатване на съдържанието на таблица.
 */
public class PrintCommand implements Command {
    private Database db;

    /**
     * Създава нова инстанция на PrintCommand.
     * @param db Обект на базата данни, върху който ще се изпълни командата.
     */
    public PrintCommand(Database db) {
        this.db = db;
    }

    /**
     * Изпълнява командата за отпечатване на таблица.
     * Синтаксис: print <table>
     * @param args Масив от аргументи за командата.
     */
    @Override
    public void execute(String[] args) {
        if (args.length != 1) {
            System.out.println("Използване: print <table>");
            return;
        }
        String tableName = args[0];
        Table table = db.getTable(tableName);
        if (table == null) {
            System.out.println("Грешка: Таблица \"" + tableName + "\" не съществува.");
            return;
        }

        // Отпечатване на имената на колоните
        System.out.println(String.join("\t", table.getColumnNames()));

        // Отпечатване на редовете
        for (List<Object> row : table.getRows()) {
            StringBuilder rowString = new StringBuilder();
            for (int i = 0; i < row.size(); i++) {
                Object value = row.get(i);
                DataType type = table.getColumnTypes().get(i);
                rowString.append(type.toString(value));
                if (i < row.size() - 1) {
                    rowString.append("\t");
                }
            }
            System.out.println(rowString.toString());
        }
    }
}
