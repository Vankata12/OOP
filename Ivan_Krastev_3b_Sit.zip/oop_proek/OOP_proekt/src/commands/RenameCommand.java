package commands;

import database.Database;

/**
 * Команда за преименуване на таблица.
 */
public class RenameCommand implements Command {
    private Database db;

    /**
     * Създава нова инстанция на RenameCommand.
     * @param db Обект на базата данни, върху който ще се изпълни командата.
     */
    public RenameCommand(Database db) {
        this.db = db;
    }

    /**
     * Изпълнява командата за преименуване на таблица.
     * Синтаксис: rename <table> <ново_име>
     * @param args Масив от аргументи за командата. Очаква се 2 аргумента: текущо име на таблицата и ново име.
     */
    @Override
    public void execute(String[] args) {
        if (args.length != 2) {
            System.out.println("Използване: rename <table> <ново_име>");
            return;
        }

        String oldName = args[0];
        String newName = args[1];

        try {
            db.renameTable(oldName, newName);
            System.out.println("Таблица \"" + oldName + "\" е преименувана на \"" + newName + "\".");
        } catch (IllegalArgumentException e) {
            System.out.println("Грешка при преименуване: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Възникна грешка при преименуване.");
        }
    }
} 