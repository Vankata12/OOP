package commands;

import database.Database;
import database.Table;

/**
 * Команда за преброяване на редове в таблица, които отговарят на дадено условие.
 */
public class CountCommand implements Command {
    private Database db;

    /**
     * Създава нова инстанция на CountCommand.
     * @param db Обект на базата данни, върху който ще се изпълни командата.
     */
    public CountCommand(Database db) {
        this.db = db;
    }

    /**
     * Изпълнява командата за преброяване.
     * Синтаксис: count <table> <col#> <value>
     * @param args Масив от аргументи за командата.
     */
    @Override
    public void execute(String[] args) {
        if (args.length != 3) {
            System.out.println("Използване: count <table> <col#> <value>");
            return;
        }

        String tableName = args[0];
        int colIndex;
        String valueString = args[2];

        Table table = db.getTable(tableName);
        if (table == null) {
            System.out.println("Грешка: Таблица \"" + tableName + "\" не съществува.");
            return;
        }

        try {
            colIndex = Integer.parseInt(args[1]);
            if (colIndex < 0 || colIndex >= table.getColumnTypes().size()) {
                System.out.println("Грешка: Невалиден индекс на колона.");
                return;
            }
        } catch (NumberFormatException e) {
            System.out.println("Грешка: Индексът на колона трябва да е число.");
            return;
        }

        // Извличане на обекта DataType за сравнение и парсване на стойността
        // Object parsedValue = table.getColumnTypes().get(colIndex).parse(valueString);
        // В текущата имплементация, сравнението е като низ. Ако е нужно парсване, трябва да се добави логика.

        long count = table.getRows().stream()
                .filter(row -> {
                    Object currentValue = row.get(colIndex);
                    if (currentValue == null) {
                        return valueString.equalsIgnoreCase("NULL");
                    } else {
                        // Сравнение като низ
                        return currentValue.toString().equals(valueString);
                    }
                })
                .count();

        System.out.println(count);
    }
}
