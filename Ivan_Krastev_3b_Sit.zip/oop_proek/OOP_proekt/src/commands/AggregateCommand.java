package commands;

import database.Database;
import database.Table;
import datatypes.DataType;
import datatypes.IntegerType;
import datatypes.FloatType;

import java.util.List;
import java.util.Objects;

/**
 * Команда за извършване на агрегатни операции върху колона в таблица.
 * Поддържа агрегатни функции като SUM, AVG, MIN, MAX.
 */
public class AggregateCommand implements Command {
    private Database db;

    /**
     * Създава нова инстанция на AggregateCommand.
     * @param db Обект на базата данни, върху който ще се изпълни командата.
     */
    public AggregateCommand(Database db) {
        this.db = db;
    }

    /**
     * Изпълнява командата за агрегатна операция.
     * Синтаксис: aggregate <table> <col#> <функция>
     * Поддържани функции: sum, avg, min, max
     * @param args Масив от аргументи за командата.
     */
    @Override
    public void execute(String[] args) {
        if (args.length != 3) {
            System.out.println("Използване: aggregate <table> <col#> <функция>");
            return;
        }

        String tableName = args[0];
        int colIndex;
        String function = args[2].toLowerCase();

        Table table = db.getTable(tableName);
        if (table == null) {
            System.out.println("Грешка: Таблица \"" + tableName + "\" не съществува.");
            return;
        }

        try {
            colIndex = Integer.parseInt(args[1]);
            if (colIndex < 0 || colIndex >= table.getColumnTypes().size()) {
                System.out.println("Грешка: Невалиден индекс на колона.");
                return;
            }
        } catch (NumberFormatException e) {
            System.out.println("Грешка: Индексът на колона трябва да е число.");
            return;
        }

        DataType colType = table.getColumnTypes().get(colIndex);

        if (!(colType instanceof IntegerType || colType instanceof FloatType)) {
            System.out.println("Грешка: Агрегатни функции се поддържат само за числови типове (int, float).");
            return;
        }

        List<Object> columnData = table.getRows().stream()
                .map(row -> row.get(colIndex))
                .filter(Objects::nonNull)
                .toList();

        if (columnData.isEmpty()) {
            System.out.println("Няма данни в колоната за агрегация.");
            return;
        }

        double result = 0;
        switch (function) {
            case "sum":
                result = columnData.stream()
                        .mapToDouble(value -> colType instanceof IntegerType ? (Integer) value : (Float) value)
                        .sum();
                System.out.println("Сума: " + result);
                break;
            case "avg":
                result = columnData.stream()
                        .mapToDouble(value -> colType instanceof IntegerType ? (Integer) value : (Float) value)
                        .average().orElse(0);
                System.out.println("Средна стойност: " + result);
                break;
            case "min":
                result = columnData.stream()
                        .mapToDouble(value -> colType instanceof IntegerType ? (Integer) value : (Float) value)
                        .min().orElse(0);
                System.out.println("Минимална стойност: " + result);
                break;
            case "max":
                result = columnData.stream()
                        .mapToDouble(value -> colType instanceof IntegerType ? (Integer) value : (Float) value)
                        .max().orElse(0);
                System.out.println("Максимална стойност: " + result);
                break;
            default:
                System.out.println("Грешка: Невалидна агрегатна функция. Поддържани функции: sum, avg, min, max.");
        }
    }
}
