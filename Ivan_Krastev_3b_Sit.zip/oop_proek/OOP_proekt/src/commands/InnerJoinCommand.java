package commands;

import database.Database;
import database.Table;
import datatypes.DataType;
import java.util.*;

/**
 * Команда за извършване на INNER JOIN операция между две таблици.
 */
public class InnerJoinCommand implements Command {
    private Database db;

    /**
     * Създава нова инстанция на InnerJoinCommand.
     * @param db Обект на базата данни, върху който ще се изпълни командата.
     */
    public InnerJoinCommand(Database db) {
        this.db = db;
    }

    /**
     * Изпълнява командата за INNER JOIN.
     * Синтаксис: innerjoin <table>1 <table>2 <col1#> <col2#>
     * Резултатът се отпечатва на конзолата.
     * @param args Масив от аргументи за командата. Очаква се 4 аргумента: име на първата таблица, име на втората таблица, индекс на колона в първата таблица, индекс на колона във втората таблица.
     */
    @Override
    public void execute(String[] args) {
        if (args.length != 4) {
            System.out.println("Използване: innerjoin <table>1 <table>2 <col1#> <col2#>");
            return;
        }

        String table1Name = args[0];
        String table2Name = args[1];
        int col1Index;
        int col2Index;

        Table table1 = db.getTable(table1Name);
        Table table2 = db.getTable(table2Name);

        if (table1 == null) {
            System.out.println("Грешка: Таблица \"" + table1Name + "\" не съществува.");
            return;
        }
        if (table2 == null) {
            System.out.println("Грешка: Таблица \"" + table2Name + "\" не съществува.");
            return;
        }

        try {
            col1Index = Integer.parseInt(args[2]);
            col2Index = Integer.parseInt(args[3]);

            if (col1Index < 0 || col1Index >= table1.getColumnTypes().size() ||
                col2Index < 0 || col2Index >= table2.getColumnTypes().size()) {
                System.out.println("Грешка: Невалидни индекси на колони.");
                return;
            }
        } catch (NumberFormatException e) {
            System.out.println("Грешка: Индексите на колони трябва да са числа.");
            return;
        }

        // Изпълнение на INNER JOIN
        System.out.println("Резултат от INNER JOIN:");
        // Отпечатване на заглавките на колоните от двете таблици
        System.out.println(String.join(", ", table1.getColumnNames()) + ", " + String.join(", ", table2.getColumnNames()));

        for (List<Object> row1 : table1.getRows()) {
            Object value1 = row1.get(col1Index);
            for (List<Object> row2 : table2.getRows()) {
                Object value2 = row2.get(col2Index);

                // Сравняване на стойностите в указаните колони (с обработка на NULL)
                if ((value1 == null && value2 == null) || (value1 != null && value2 != null && value1.equals(value2))) {
                    // Ако стойностите съвпадат (или и двете са NULL), отпечатваме комбинирания ред
                    List<Object> combinedRow = new ArrayList<>(row1);
                    combinedRow.addAll(row2);
                    System.out.println(combinedRow.stream()
                        .map(val -> val == null ? "NULL" : val.toString())
                        .collect(java.util.stream.Collectors.joining(", ")));
                }
            }
        }
    }
} 