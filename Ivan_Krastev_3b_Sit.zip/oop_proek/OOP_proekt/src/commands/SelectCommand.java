package commands;

import database.Database;
import database.Table;
import datatypes.DataType;

import java.util.List;
import java.util.Scanner;

/**
 * Команда за избиране и показване на редове от таблица по дадено условие.
 * Поддържа страниране на резултатите за по-добра четимост.
 */
public class SelectCommand implements Command {
    private final Database db;
    private static final int PAGE_SIZE = 10;

    /**
     * Създава нова инстанция на SelectCommand.
     * @param db Обект на базата данни, върху който ще се изпълни командата.
     */
    public SelectCommand(Database db) {
        this.db = db;
    }

    /**
     * Изпълнява командата за избиране на редове.
     * Синтаксис: select <column#> <value> <table>
     * Показва редовете на страници, като позволява навигация между тях.
     * @param args Масив от аргументи за командата.
     */
    @Override
    public void execute(String[] args) {
        if (args.length != 3) {
            System.out.println("Използване: select <column#> <value> <table>");
            return;
        }

        int col = Integer.parseInt(args[0]);
        String val = args[1];
        Table table = db.getTable(args[2]);
        List<List<Object>> rows = table.getRows().stream()
            .filter(r -> r.get(col) != null && table.getColumnTypes().get(col).toString(r.get(col)).equals(val))
            .toList();

        if (rows.isEmpty()) {
            System.out.println("Няма намерени редове.");
            return;
        }

        Scanner scanner = new Scanner(System.in);
        int page = 0;
        while (true) {
            int start = page * PAGE_SIZE;
            int end = Math.min(start + PAGE_SIZE, rows.size());
            System.out.println("-- Страница " + (page + 1) + " --");
            for (int i = start; i < end; i++) {
                List<Object> row = rows.get(i);
                for (int j = 0; j < row.size(); j++) {
                    System.out.print(table.getColumnTypes().get(j).toString(row.get(j)) + "\t");
                }
                System.out.println();
            }
            System.out.println("[next] [prev] [exit]");
            String input = scanner.nextLine().trim().toLowerCase();
            if (input.equals("next") && end < rows.size()) page++;
            else if (input.equals("prev") && page > 0) page--;
            else if (input.equals("exit")) break;
        }
    }
}
