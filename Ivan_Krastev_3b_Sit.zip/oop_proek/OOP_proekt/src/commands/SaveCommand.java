package commands;

import database.Database;
import database.FileHandler;

/**
 * Команда за записване на текущата база данни.
 * Данните се записват в асоциирания каталог файл и съответните .tbl файлове.
 */
public class SaveCommand implements Command {
    private Database db;

    /**
     * Създава нова инстанция на SaveCommand.
     * @param db Обект на базата данни, върху който ще се изпълни командата.
     */
    public SaveCommand(Database db) {
        this.db = db;
    }

    /**
     * Изпълнява командата за записване.
     * Синтаксис: save
     * @param args Масив от аргументи за командата (не се използват в този случай).
     */
    @Override
    public void execute(String[] args) {
        try {
            FileHandler.saveDatabase(db);
            System.out.println("Базата данни е записана успешно.");
        } catch (Exception e) {
            System.out.println("Грешка при запис: " + e.getMessage());
        }
    }
} 