package commands;

import database.Database;
import database.Table;
import datatypes.DataType;
import java.util.ArrayList;
import java.util.List;

/**
 * Команда за изтриване на редове от таблица по дадено условие.
 */
public class DeleteCommand implements Command {
    private Database db;

    /**
     * Създава нова инстанция на DeleteCommand.
     * @param db Обект на базата данни, върху който ще се изпълни командата.
     */
    public DeleteCommand(Database db) {
        this.db = db;
    }

    /**
     * Изпълнява командата за изтриване на редове.
     * Синтаксис: delete <table> <col#> <value>
     * @param args Масив от аргументи за командата.
     */
    @Override
    public void execute(String[] args) {
        if (args.length != 3) {
            System.out.println("Използване: delete <table> <col#> <value>");
            return;
        }

        String tableName = args[0];
        Table table = db.getTable(tableName);
        
        if (table == null) {
            System.out.println("Таблицата " + tableName + " не съществува.");
            return;
        }

        try {
            int col = Integer.parseInt(args[1]);
            if (col < 0 || col >= table.getColumnTypes().size()) {
                System.out.println("Невалиден номер на колона. Моля, използвайте число между 0 и " + (table.getColumnTypes().size() - 1));
                return;
            }

            String valueString = args[2];
            DataType compareColType = table.getColumnTypes().get(col);
            Object parsedValue = compareColType.parse(valueString);

            int deletedCount = table.deleteRows(col, parsedValue);

            System.out.println("Изтрити " + deletedCount + " редове от таблица " + tableName);
        } catch (NumberFormatException e) {
            System.out.println("Невалиден номер на колона. Моля, въведете число.");
        } catch (Exception e) {
            System.out.println("Грешка при изтриване: " + e.getMessage());
        }
    }
}
