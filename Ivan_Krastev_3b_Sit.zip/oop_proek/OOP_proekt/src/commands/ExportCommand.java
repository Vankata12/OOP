package commands;

import database.Database;
import database.FileHandler;
import database.Table;

import java.io.IOException;

/**
 * Команда за експортиране на таблица във файл.
 */
public class ExportCommand implements Command {
    private final Database database;

    /**
     * Създава нова инстанция на ExportCommand.
     * @param database Обект на базата данни, върху който ще се изпълни командата.
     */
    public ExportCommand(Database database) {
        this.database = database;
    }

    /**
     * Изпълнява командата за експортиране на таблица.
     * Синтаксис: export <table> <файл>
     * @param args Масив от аргументи за командата.
     */
    @Override
    public void execute(String[] args) {
        if (args.length != 2) {
            System.out.println("Използване: export <table> <файл>");
            return;
        }

        String tableName = args[0];
        String fileName = args[1].replaceAll("^\\\"|\\\"$", ""); // Премахва кавичките

        Table table = database.getTable(tableName);
        if (table == null) {
            System.out.println("Грешка: Таблица \"" + tableName + "\" не съществува.");
            return;
        }

        try {
            FileHandler.exportTable(table, fileName);
            System.out.println("Таблицата \"" + tableName + "\" е експортирана успешно във файл \"" + fileName + "\".");
        } catch (IOException e) {
            System.out.println("Грешка при експортиране: " + e.getMessage());
        } catch (Exception ex) {
            System.out.println("Грешка при експортиране: Невалидни данни в таблицата или проблем с формата.");
        }
    }
} 