package commands;

import database.Database;
import database.Table;
import datatypes.DataType;
import java.util.ArrayList;
import java.util.List;

/**
 * Команда за вмъкване на нов ред в таблица.
 */
public class InsertCommand implements Command {
    private Database db;

    /**
     * Създава нова инстанция на InsertCommand.
     * @param db Обект на базата данни, върху който ще се изпълни командата.
     */
    public InsertCommand(Database db) {
        this.db = db;
    }

    /**
     * Изпълнява командата за вмъкване на ред.
     * Синтаксис: insert <table> <стойност1> <стойност2> ...
     * @param args Масив от аргументи за командата.
     */
    @Override
    public void execute(String[] args) {
        if (args.length < 2) {
            System.out.println("Използване: insert <table> <стойност1> <стойност2> ...");
            return;
        }

        String tableName = args[0];
        Table table = db.getTable(tableName);
        if (table == null) {
            System.out.println("Грешка: Таблица \"" + tableName + "\" не съществува.");
            return;
        }

        List<Object> rowValues = new ArrayList<>();
        List<DataType> columnTypes = table.getColumnTypes();

        if (args.length - 1 != columnTypes.size()) {
            System.out.println("Грешка: Невалиден брой стойности. Очаквани: " + columnTypes.size() + ". Получени: " + (args.length - 1) + ".");
            return;
        }

        try {
            for (int i = 0; i < columnTypes.size(); i++) {
                String valueString = args[i + 1];
                DataType type = columnTypes.get(i);
                if (valueString.equalsIgnoreCase("NULL")) {
                    rowValues.add(null);
                } else {
                    // Валидация и парсване според типа
                    if (!type.isValid(valueString)) {
                         System.out.println("Грешка: Невалидна стойност \"" + valueString + "\" за колона \"" + table.getColumnNames().get(i) + "\" (тип " + type.getClass().getSimpleName() + ").");
                         return;
                    }
                    rowValues.add(type.parse(valueString));
                }
            }
            table.addRow(rowValues);
            System.out.println("Редът е вмъкнат успешно в таблица \"" + tableName + "\".");
        } catch (IllegalArgumentException e) {
             System.out.println("Грешка при вмъкване: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Грешка при вмъкване: Невалиден формат на данните.");
        }
    }
}
