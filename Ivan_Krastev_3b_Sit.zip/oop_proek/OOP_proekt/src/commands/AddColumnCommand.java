 package commands;

import database.Database;
import database.Table;
import datatypes.DataType;
import datatypes.DataTypeFactory;
import java.util.Arrays;
import java.util.List;

/**
 * Команда за добавяне на нова колона към съществуваща таблица.
 */
public class AddColumnCommand implements Command {
    private Database db;

    /**
     * Създава нова инстанция на AddColumnCommand.
     * @param db Обект на базата данни, върху който ще се изпълни командата.
     */
    public AddColumnCommand(Database db) {
        this.db = db;
    }

    /**
     * Изпълнява командата за добавяне на колона.
     * Синтаксис: addcolumn <table> <име_на_колона> <тип_на_данните>
     * @param args Масив от аргументи за командата.
     */
    @Override
    public void execute(String[] args) {
        if (args.length != 3) {
            System.out.println("Използване: addcolumn <table> <име_на_колона> <тип_на_данните>");
            return;
        }

        String tableName = args[0];
        String columnName = args[1];
        String columnTypeString = args[2];

        Table table = db.getTable(tableName);
        if (table == null) {
            System.out.println("Грешка: Таблица \"" + tableName + "\" не съществува.");
            return;
        }

        DataType columnType = DataTypeFactory.createType(columnTypeString);
        if (columnType == null) {
            System.out.println("Грешка: Невалиден тип данни \"" + columnTypeString + "\". Поддържани типове: int, float, string.");
            return;
        }

        table.addColumn(columnName, columnType);
        System.out.println("Колона \"" + columnName + "\" с тип \"" + columnTypeString + "\" е добавена към таблица \"" + tableName + "\".");
    }
} 