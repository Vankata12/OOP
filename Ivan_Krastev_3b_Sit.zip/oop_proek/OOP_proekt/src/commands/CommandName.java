package commands;

/**
 * Изброяване (Enum) на всички поддържани команди в системата.
 */
public enum CommandName {
    IMPORT,
    SHOWTABLES,
    DESCRIBE,
    PRINT,
    INSERT,
    DELETE,
    UPDATE,
    COUNT,
    AGGREGATE,
    HELP,
    EXIT,
    EXPORT,
    ADDCOLUMN,
    INNERJOIN,
    RENAME,
    CLOSE,
    SAVE,
    SAVEAS
}
