package commands;

import database.Database;

/**
 * Команда за затваряне на текущата база данни.
 * Предлага записване на промените преди затваряне.
 */
public class CloseCommand implements Command {
    private Database db;

    /**
     * Създава нова инстанция на CloseCommand.
     * @param db Обект на базата данни, върху който ще се изпълни командата.
     */
    public CloseCommand(Database db) {
        this.db = db;
    }

    /**
     * Изпълнява командата за затваряне на базата данни.
     * @param args Масив от аргументи за командата (не се използват в този случай).
     */
    @Override
    public void execute(String[] args) {
        db.getTableNames().forEach(name -> db.removeTable(name));
        System.out.println("Базата данни е затворена (всички таблици са изчистени от паметта).");
    }
} 