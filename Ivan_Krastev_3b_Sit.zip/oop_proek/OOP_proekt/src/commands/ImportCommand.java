package commands;

import database.Database;
import database.FileHandler;
import database.Table;

import java.io.File;
import java.io.IOException;

/**
 * Команда за импортиране на таблица от файл.
 * Ако файлът не съществува, създава нова празна таблица в паметта.
 */
public class ImportCommand implements Command {
    private final Database database;

    /**
     * Създава нова инстанция на ImportCommand.
     * @param database Обект на базата данни, върху който ще се изпълни командата.
     */
    public ImportCommand(Database database) {
        this.database = database;
    }

    /**
     * Изпълнява командата за импортиране.
     * Синтаксис: import <файл>
     * @param args Масив от аргументи за командата. Очаква се един аргумент - името на файла за импортиране.
     */
    @Override
    public void execute(String[] args) {
        if (args.length != 1) {
            System.out.println("Използване: import <file name>");
            return;
        }

        String fileName = args[0].replaceAll("^\\\"|\\\"$", ""); // Премахва кавичките от аргумента
        String tableName = fileName;
        if (tableName.contains(".")) {
            tableName = tableName.substring(0, tableName.lastIndexOf("."));
        }

        File file = new File(fileName);
        if (!file.exists()) {
            // Ако файлът не съществува, създаваме нова празна таблица
            if (database.getTableNames().contains(tableName)) {
                 System.out.println("Грешка: Таблица с име \"" + tableName + "\" вече е заредена.");
            } else {
                Table newTable = new Table(tableName);
                database.addTable(newTable);
                System.out.println("Създадена е нова празна таблица \"" + tableName + "\".");
            }
            return;
        }

        try {
            Table t = FileHandler.importTable(fileName);
            if (database.getTableNames().contains(t.getName())) {
                System.out.println("Грешка: Таблица с име \"" + t.getName() + "\" вече е заредена.");
            } else {
                database.addTable(t);
                System.out.println("✅ Таблицата \"" + t.getName() + "\" е импортирана успешно.");
            }
        } catch (IOException e) {
            System.out.println("Грешка при импортиране от файл: " + e.getMessage());
        } catch (Exception ex) {
            System.out.println("Невалиден формат на таблицата или типове във файл \"" + fileName + "\": " + ex.getMessage());
        }
    }
}
