package commands;

import database.Database;

/**
 * Команда за показване на имената на всички заредени таблици в базата данни.
 */
public class ShowTablesCommand implements Command {
    private Database db;

    /**
     * Създава нова инстанция на ShowTablesCommand.
     * @param db Обект на базата данни, върху който ще се изпълни командата.
     */
    public ShowTablesCommand(Database db) {
        this.db = db;
    }

    /**
     * Изпълнява командата за показване на таблици.
     * Синтаксис: showtables
     * @param args Масив от аргументи за командата (не се използват в този случай).
     */
    @Override
    public void execute(String[] args) {
        System.out.println("Налични таблици:");
        if (db.getTableNames().isEmpty()) {
            System.out.println("  (Няма заредени таблици)");
        } else {
            for (String tableName : db.getTableNames()) {
                System.out.println("- " + tableName);
            }
        }
    }
}
