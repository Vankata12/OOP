package datatypes;

/**
 * Фабричен клас за създаване на инстанции на различни типове данни.
 */
public class DataTypeFactory {

    /**
     * Създава инстанция на тип данни по даден низ.
     * @param typeName Низ, представляващ името на типа данни (напр. "int", "float", "string").
     * @return Инстанция на съответния тип данни или null, ако името на типа е невалидно.
     */
    public static DataType createType(String typeName) {
        return switch (typeName.toLowerCase()) {
            case "int" -> new IntegerType();
            case "float" -> new FloatType();
            case "string" -> new StringType();
            default -> null;
        };
    }

    /**
     * Връща класа на типа данни по дадено име.
     * @param typeName Низ, представляващ името на типа данни.
     * @return Клас на съответния тип данни.
     * @throws IllegalArgumentException ако името на типа е неподдържано.
     */
    public static Class<? extends DataType> getTypeClass(String typeName) {
        switch (typeName.trim().toLowerCase()) {
            case "integer":
            case "integertype":
                return IntegerType.class;
            case "float":
            case "floattype":
                return FloatType.class;
            case "string":
            case "stringtype":
                return StringType.class;
            default:
                throw new IllegalArgumentException("Неподдържан тип данни: " + typeName);
        }
    }

}
