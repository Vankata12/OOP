package datatypes;

/**
 * Представлява тип данни Float в базата данни.
 */
public class FloatType extends DataType {

    /**
     * Парсва низ към Float.
     * @param value Низът за парсване.
     * @return Обект от тип Float.
     * @throws IllegalArgumentException ако низът не може да бъде парснат като Float.
     */
    @Override
    public Object parse(String value) {
        if (value == null || value.equalsIgnoreCase("NULL")) return null;
        try {
            return Float.parseFloat(value);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Невалиден формат за Float: " + value);
        }
    }

    /**
     * Проверява дали даден низ е валиден за Float (игнорира "NULL").
     * @param value Низът за валидация.
     * @return true, ако низът може да бъде парснат като Float или е "NULL", в противен случай false.
     */
    @Override
    public boolean isValid(String value) {
        if (value == null || value.equalsIgnoreCase("NULL")) return true;
        try {
            Float.parseFloat(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Преобразува Float стойност в низ.
     * @param value Стойността за преобразуване (очаква се Float или null).
     * @return Низ представяне на стойността или "NULL".
     */
    @Override
    public String toString(Object value) {
        if (value == null) return "NULL";
        return value.toString();
    }
} 