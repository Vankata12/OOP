 package datatypes;

/**
 * Абстрактен клас, представляващ тип данни в базата данни.
 * Дефинира основните методи за парсване, валидация и преобразуване към низ.
 */
public abstract class DataType {

    /**
     * Парсва низ към съответния тип данни.
     * @param value Низът за парсване.
     * @return Обект със стойността на типа данни.
     * @throws IllegalArgumentException ако низът е в невалиден формат за типа данни.
     */
    public abstract Object parse(String value);

    /**
     * Проверява дали даден низ е валиден за типа данни.
     * @param value Низът за валидация.
     * @return true, ако низът е валиден, в противен случай false.
     */
    public abstract boolean isValid(String value);

    /**
     * Преобразува стойност от типа данни в низ за запис.
     * @param value Стойността за преобразуване.
     * @return Низ представяне на стойността.
     */
    public abstract String toString(Object value);
} 