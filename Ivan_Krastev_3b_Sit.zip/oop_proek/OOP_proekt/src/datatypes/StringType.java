package datatypes;

/**
 * Представлява тип данни String в базата данни.
 */
public class StringType extends DataType {
    /**
     * Парсва низ към String.
     * @param value Низът за парсване.
     * @return Обект от тип String или null, ако низът е "NULL".
     */
    @Override
    public Object parse(String value) {
        if (value == null || value.equalsIgnoreCase("NULL")) return null;
        return value;
    }

    /**
     * Проверява дали даден низ е валиден за String (винаги true).
     * @param value Низът за валидация.
     * @return винаги true.
     */
    @Override
    public boolean isValid(String value) {
        return true; // Всички низове са валидни за StringType
    }

    /**
     * Преобразува String стойност в низ.
     * @param value Стойността за преобразуване (очаква се String или null).
     * @return Низ представяне на стойността или "NULL".
     */
    @Override
    public String toString(Object value) {
        if (value == null) return "NULL";
        return (String) value;
    }
} 