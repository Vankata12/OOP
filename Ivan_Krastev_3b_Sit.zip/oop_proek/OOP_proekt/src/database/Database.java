package database;

import java.util.*;
import java.io.*;

/**
 * Клас, представляващ база данни.
 * Съдържа колекция от таблици и информация за каталог файла.
 * 
 * @author Your Name
 * @version 1.0
 */
public class Database {
    private String name;
    private Map<String, Table> tables;
    private String catalogFile;
    
    /**
     * Създава нова база данни.
     * @param name Името на базата данни.
     * @param catalogFile Името на файл, който ще се използва за каталог.
     */
    public Database(String name, String catalogFile) {
        this.name = name;
        this.tables = new HashMap<>();
        this.catalogFile = catalogFile;
    }
    
    /**
     * Добавя нова таблица в базата данни.
     * 
     * @param table таблицата за добавяне
     * @throws IllegalArgumentException ако таблица с това име вече съществува
     */
    public void addTable(Table table) throws IllegalArgumentException {
        if (tables.containsKey(table.getName())) {
            throw new IllegalArgumentException("Таблица с това име вече съществува");
        }
        tables.put(table.getName(), table);
    }
    
    /**
     * Премахва таблица от базата данни.
     * 
     * @param tableName име на таблицата за премахване
     * @throws IllegalArgumentException ако таблицата не съществува
     */
    public void removeTable(String tableName) throws IllegalArgumentException {
        if (!tables.containsKey(tableName)) {
            throw new IllegalArgumentException("Таблицата не съществува");
        }
        tables.remove(tableName);
    }
    
    /**
     * Връща таблица по име.
     * 
     * @param tableName име на таблицата
     * @return таблицата с даденото име
     * @throws IllegalArgumentException ако таблицата не съществува
     */
    public Table getTable(String tableName) throws IllegalArgumentException {
        if (!tables.containsKey(tableName)) {
            throw new IllegalArgumentException("Таблицата не съществува");
        }
        return tables.get(tableName);
    }
    
    /**
     * Преименува таблица в базата данни.
     * 
     * @param oldName старо име на таблицата
     * @param newName ново име на таблицата
     * @throws IllegalArgumentException ако таблицата не съществува или новото име вече е заето
     */
    public void renameTable(String oldName, String newName) throws IllegalArgumentException {
        if (!tables.containsKey(oldName)) {
            throw new IllegalArgumentException("Таблицата не съществува");
        }
        if (tables.containsKey(newName)) {
            throw new IllegalArgumentException("Таблица с новото име вече съществува");
        }
        Table table = tables.remove(oldName);
        table.setName(newName);
        tables.put(newName, table);
    }
    
    /**
     * Връща множество с имената на всички таблици в базата данни.
     * 
     * @return множество с имената на таблиците
     */
    public Set<String> getTableNames() {
        return new HashSet<>(tables.keySet());
    }
    
    /**
     * Връща името на базата данни.
     * @return Името на базата данни.
     */
    public String getName() {
        return name;
    }
    
    /**
     * Връща пътя до файла за каталог.
     * @return Името на каталог файла.
     */
    public String getCatalogFile() {
        return catalogFile;
    }
    
    /**
     * Задава името на каталог файла.
     * @param catalogFile Новото име на каталог файла.
     */
    public void setCatalogFile(String catalogFile) {
        this.catalogFile = catalogFile;
    }
} 