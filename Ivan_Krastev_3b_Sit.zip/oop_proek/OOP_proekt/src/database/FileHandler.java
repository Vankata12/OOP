package database;

import datatypes.*;
import java.io.*;
import java.util.*;

/**
 * Клас за работа с файлове в базата данни (импорт, експорт, запис).
 */
public class FileHandler {

    /**
     * Записва текущата база данни във файлове.
     * Данните се записват в каталог файла и отделни .tbl файлове за всяка таблица.
     * @param database Обектът на базата данни за записване.
     * @throws IOException при грешка при работа с файлове.
     */
    public static void saveDatabase(Database database) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(database.getCatalogFile()))) {
            writer.println(database.getName());
            for (String tableName : database.getTableNames()) {
                writer.println(tableName + "," + tableName + ".tbl");
                exportTable(database.getTable(tableName), tableName + ".tbl");
            }
        }
    }

    /**
     * Импортира таблица от .tbl файл.
     * Прочита данните от файла и създава обект Table.
     * @param filename името на файла за импортиране.
     * @return Обект Table, представляващ импортираната таблица.
     * @throws IOException при грешка при четене от файл.
     * @throws IllegalArgumentException при невалиден формат на файла или данни.
     */
    public static Table importTable(String filename) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String tableName = new File(filename).getName().replaceFirst("[.][^.]+$", "");
            Table table = new Table(tableName);

            String[] columnNames = reader.readLine().split(",");
            String[] columnTypes = reader.readLine().split(",");

            for (int i = 0; i < columnNames.length; i++) {
                DataType type = DataTypeFactory.createType(columnTypes[i]);
                table.addColumn(columnNames[i], type);
            }

            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split(",");
                List<Object> row = new ArrayList<>();
                List<DataType> types = table.getColumnTypes();
                for (int i = 0; i < values.length; i++) {
                    String value = values[i];
                    DataType type = types.get(i);

                    // Валидация преди парсването за StringType
                    if (type instanceof StringType) {
                        if (!((StringType) type).isValid(value)) {
                            throw new IllegalArgumentException("Невалидна стойност за колона " + table.getColumnNames().get(i) + " във файла.");
                        }
                    }
                    // Проверка за NULL и парсване
                    if (value.equals("NULL")) {
                        row.add(null);
                    } else {
                        row.add(type.parse(value));
                    }
                }
                table.addRow(row);
            }
            return table;
        }
    }

    /**
     * Експортира таблица във .tbl файл.
     * Записва структурата и данните на таблицата във файл.
     * @param table Таблицата за експортиране.
     * @param filename името на файла, в който ще се експортира таблицата.
     * @throws IOException при грешка при запис във файл.
     */
    public static void exportTable(Table table, String filename) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            writer.println(String.join(",", table.getColumnNames()));
            List<String> typeNames = new ArrayList<>();
            for (DataType type : table.getColumnTypes()) {
                typeNames.add(type.getClass().getSimpleName());
            }
            writer.println(String.join(",", typeNames));
            for (List<Object> row : table.getRows()) {
                List<String> values = new ArrayList<>();
                List<DataType> types = table.getColumnTypes();
                for (int i = 0; i < row.size(); i++) {
                    values.add(types.get(i).toString(row.get(i)));
                }
                writer.println(String.join(",", values));
            }
        }
    }
}
