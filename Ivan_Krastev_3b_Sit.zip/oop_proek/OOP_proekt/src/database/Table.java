package database;

import datatypes.DataType;
import java.util.*;

/**
 * Клас, представляващ таблица в базата данни.
 * Съдържа колони с имена и типове, както и редове с данни.
 * 
 * @author Your Name
 * @version 1.0
 */
public class Table {
    private String name;
    private List<String> columnNames;
    private List<DataType> columnTypes;
    private List<List<Object>> rows;
    
    /**
     * Създава нова празна таблица с дадено име.
     * 
     * @param name име на таблицата
     */
    public Table(String name) {
        this.name = name;
        this.columnNames = new ArrayList<>();
        this.columnTypes = new ArrayList<>();
        this.rows = new ArrayList<>();
    }
    
    /**
     * Добавя нова колона в таблицата.
     * 
     * @param name име на колоната
     * @param type тип на данните в колоната
     */
    public void addColumn(String name, DataType type) {
        columnNames.add(name);
        columnTypes.add(type);
        for (List<Object> row : rows) {
            row.add(null);
        }
    }
    
    /**
     * Добавя нов ред в таблицата.
     * 
     * @param row списък със стойности за реда
     * @throws IllegalArgumentException ако броят на колоните не съвпада или типовете данни са невалидни
     */
    public void addRow(List<Object> row) throws IllegalArgumentException {
        if (row.size() != columnTypes.size()) {
            throw new IllegalArgumentException("Невалиден брой колони");
        }
        
        for (int i = 0; i < row.size(); i++) {
            if (!columnTypes.get(i).isValid(row.get(i) == null ? "NULL" : row.get(i).toString())) {
                throw new IllegalArgumentException("Невалидна стойност за колона " + columnNames.get(i));
            }
        }
        
        rows.add(new ArrayList<>(row));
    }
    
    /**
     * Връща името на таблицата.
     * 
     * @return име на таблицата
     */
    public String getName() {
        return name;
    }
    
    /**
     * Задава ново име на таблицата.
     * 
     * @param name ново име на таблицата
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * Връща списък с имената на колоните.
     * 
     * @return списък с имената на колоните
     */
    public List<String> getColumnNames() {
        return new ArrayList<>(columnNames);
    }
    
    /**
     * Връща списък с типовете на колоните.
     * 
     * @return списък с типовете на колоните
     */
    public List<DataType> getColumnTypes() {
        return new ArrayList<>(columnTypes);
    }
    
    /**
     * Връща списък с редовете на таблицата.
     * 
     * @return списък с редовете на таблицата
     */
    public List<List<Object>> getRows() {
        return new ArrayList<>(rows);
    }

    /**
     * Изтрива редове от таблицата, които съвпадат с дадена стойност в определена колона.
     * 
     * @param colIndex индекс на колоната за сравнение
     * @param value стойност за сравнение
     * @return броя на изтритите редове
     */
    public int deleteRows(int colIndex, Object value) {
        int initialSize = rows.size();
        rows.removeIf(row -> {
            Object currentValue = row.get(colIndex);
            if (currentValue == null && value == null) {
                return true; // И двете са NULL, редът трябва да се изтрие
            } else if (currentValue != null && value != null) {
                // Използваме equals за коректно сравнение на обекти
                return currentValue.equals(value);
            }
            return false; // Едното е NULL, другото не е, редът не трябва да се изтрие
        });
        return initialSize - rows.size();
    }
} 