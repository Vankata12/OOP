import commands.*;
import database.*;
import java.util.*;

/**
 * Основен клас на програмата за управление на база данни.
 * Обработва въвеждането на команди от потребителя и ги изпълнява.
 */
public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final Database currentDatabase = new Database("default", "catalog.txt");
    private static final Map<CommandName, Command> commandMap = new EnumMap<>(CommandName.class);

    static {
        // Инициализация на картата с команди
        commandMap.put(CommandName.IMPORT, new ImportCommand(currentDatabase));
        commandMap.put(CommandName.SHOWTABLES, new ShowTablesCommand(currentDatabase));
        commandMap.put(CommandName.DESCRIBE, new DescribeCommand(currentDatabase));
        commandMap.put(CommandName.PRINT, new PrintCommand(currentDatabase));
        commandMap.put(CommandName.INSERT, new InsertCommand(currentDatabase));
        commandMap.put(CommandName.DELETE, new DeleteCommand(currentDatabase));
        commandMap.put(CommandName.UPDATE, new UpdateCommand(currentDatabase));
        commandMap.put(CommandName.COUNT, new CountCommand(currentDatabase));
        commandMap.put(CommandName.AGGREGATE, new AggregateCommand(currentDatabase));
        commandMap.put(CommandName.HELP, new HelpCommand());
        commandMap.put(CommandName.EXIT, new ExitCommand());
        commandMap.put(CommandName.EXPORT, new ExportCommand(currentDatabase));
        commandMap.put(CommandName.ADDCOLUMN, new AddColumnCommand(currentDatabase));
        commandMap.put(CommandName.INNERJOIN, new InnerJoinCommand(currentDatabase));
        commandMap.put(CommandName.RENAME, new RenameCommand(currentDatabase));
        commandMap.put(CommandName.CLOSE, new CloseCommand(currentDatabase));
        commandMap.put(CommandName.SAVE, new SaveCommand(currentDatabase));
        commandMap.put(CommandName.SAVEAS, new SaveAsCommand(currentDatabase));
    }

    /**
     * Основен метод за стартиране на програмата.
     * Влиза в цикъл за четене и изпълнение на команди от стандартния вход.
     * @param args Аргументи от командния ред (не се използват в този случай).
     */
    public static void main(String[] args) {
        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine().trim();
            if (input.isEmpty()) continue;

            String[] tokens = input.split("\s+");
            try {
                CommandName cmd = CommandName.valueOf(tokens[0].toUpperCase());
                String[] arguments = Arrays.copyOfRange(tokens, 1, tokens.length);
                commandMap.getOrDefault(cmd, a -> System.out.println("Невалидна команда.")).execute(arguments);
            } catch (IllegalArgumentException e) {
                System.out.println("Невалидна команда.");
            }
        }
    }
}
